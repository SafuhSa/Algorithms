class App < Sinatra::Base
  configure do
    # mongo
    begin
      mongo_db = Mongo::Connection.new.db "data-test"
      set :mongo_db, mongo_db
    rescue Mongo::ConnectionFailure
      set :mongo_db, {}
    end
  end
  get "/?" do
    haml :index
  end
  get "/area" do
    
  end
  get "/restaurants" do
    
  end
end