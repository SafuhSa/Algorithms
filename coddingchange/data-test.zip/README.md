data-test
=========

Test project for DK prospects

Controller and model files have been damaged during transfer.

Additionally, mongoid configuration, boot.rb, Procfile & unicorn.rb are missing. These are required in order to run the project on Heroku.

1. Recreate configuration files.

2. Run all rake tasks in their respective order to instantiate a copy of the database.

3. Restore controller file so that CONTROLLER TEST section example queries should result in example output.

CONTROLLER TEST
===============

http://localhost:9393/area?lat=3&lng=5
[{"_id":{"$oid":"53c83c39d8533bb424000001"},"boundaries":{"type":"Polygon","coordinates":[[[0,0],[3,6],[6,3],[3,1],[0,0]]]}}]

http://localhost:9393/restaurants?lat=1&lng=1&distance=500
[{"name":"Restaurant Two","_id":"restaurant-two","distance":154.4769776801178,"store":{"_id":{"$oid":"53c99ffdd8533bc0e0000004"},"number":2,"rid":"restaurant-two","loc":[2,3]}}]

BONUS
=====

Include area in each returned restaurant record on /restaurants endpoint.


HELP
====

If you are unfamiliar with some of the technologies (i.e. Mongo), feel free to browse their docs and use Google. Most if not all of the solutions in this test can be found online.


NOTES
=====

Please do not actually deploy the project on Heroku and don't upload it to GitHub or any other publicly accessible website.
